 #read the content from file
try:
    