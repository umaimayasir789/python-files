 #eample 7
#nested try block
try:
    try:
        x = int("abc")# attempt to convert non-numeric string to integer
    except ValueError:
        print("inner exception :invalid conversion") #handle the inner exception
    y = 10/0
except ZeroDivisionError:
   print("outer exception :division by zero")