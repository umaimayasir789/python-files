   #using try except in loops 
for I in range(3):
    try:
        number = int(input("enter a number"))
        print("you entered:",number)
        break               # exit loop 
    except ValueError:
        print("please try again with a valid number")