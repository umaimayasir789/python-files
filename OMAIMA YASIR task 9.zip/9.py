 # exception handling       (undefined values) try: ,except exception type:
#example 1
try: 
    result = 10/0   #trying to divide by zero will raise an exception
except ZeroDivisionError:
 print("you cant divide by zero")   #handle the exception with acustom msg
#example 2
try:
   age = int(input("enter your age:"))
except ValueError:
  print("invalid input please input a number")
  # using else and finally example 3
try:
     num = int(input("enter a number:"))       #attemp to input an integer
except ValueError:
   print("not a number")  #catch the value error if input is not valid 
else :
   print("you entered:",num)   #if no exception then print number
finally:
   print("this always runs")    #this block runs no matter what

  