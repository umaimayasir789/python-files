try: 
    num = int(input("enter a number"))
    result = num/0   #trying to divide by zero will raise an exception
except ZeroDivisionError:
     print("you cant divide by zero") 
except ValueError:
      print("invalid input please input a number")
except Exception as e:
     print("an unexpected error occurred",e)