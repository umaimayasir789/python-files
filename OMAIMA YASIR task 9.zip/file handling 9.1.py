 # we can download from collab 
#create a write to a file
try:
 with open("example.txt","w")  as file:        #in write mode("w")
#the "with statment ensures file is properly closed after  writing with open"
  # write a line of text to the file
  file.write("hello,this is a test file. \n") #first time
  file.write("IT was created in google collab \n")
  file.write("you are learning how to handle files in python!\n")  #third line
# if evreything goes well print this
  print("file created and data written successfully")
except Exception as e:
# if error occur during writing 
  print("an error occurred:",e)
finally:
#this block always runs 
  print("finished writing to the file")