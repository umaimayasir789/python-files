try:
   age = int(input("enter your age:"))
   if age > 18:
      raise underageerror
    print("your age is" ,age)
    break
except underageerror:
  print("error: you must be 18 or older")
  