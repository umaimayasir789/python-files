 #before
print("item 1:apple")
print("item 2:banana")
print("item 3: mango")
#after
items =["Apple","Banana","Mango"]
for i, item in enumerate(items, start=1):
    print(f"Item {i}: {item}")


