 #Activity 5: Refactor a Messy Student Record Program
#Task
#Here is a messy code that manages student records.
#Your job is to refactor it to make it:
#·Clean
# Well-organized
#Easy to add more students
#Before Refactoring
 #{print("Name: Ali")
#print("Age: 20")
#print("Course: Computer Science")
#print("Name:Sara")
#print("Age: 22")
#print("Course: Software Engineering")
#print("Name: John")
#print("Age:19")
#print("Course: Artificial Intelligence")}
#after
def student(name , age , course):
  print(f"name {name}")
  print(f"age {age}")
  print(f"course {course}")
  #students = [
student(name= "Ali", age="20", course="SE")
student(name="sara", age="23", course="IT")
student(name="John", age="22", course="Ai")  
    
