users={
  "admin":" admin123" , "teacher":"teacher123" , "student":"student123"
 }
username=input("enter username:")
Password=input("enter password:")
if username in users and users[username] == Password:
     print("welcome ", username)
else:
    print("invalid credentials")