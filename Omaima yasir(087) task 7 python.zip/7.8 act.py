def student_login(username,password):
    if username=="student" and password=="pass123":
        print("welcome, student")
    else:
        print("invalid user credentails")
           
def teacher_login(username,password):
    if username=="teacher" and password=="teach123":
        print("welcome, teacher")
    else:
        print("invalid teacher credentails") 
def admin_login(username,password):
    if username=="admin" and password=="admin123":
        print("welcome, student")
    else:
        print("invalid admin credentails")


usertype = input("Enter usertype: ")
username = input("Enter username: ")  
password = input("Enter password: ") 
if usertype == "student":
    student_login(username,password)
elif usertype== "teacher":
    teacher_login(username,password)
elif usertype=="admin":
    admin_login(username,password)
else:
    print("invalid usertype")