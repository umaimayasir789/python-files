 #split a big function into smaller one:
#usability increase krna ka liye hai (changing easy ho jaya gi)
#before
#def user_activity():
 #print("logging in....")
 #print("fetching data....")
 #print("displaying dashboard...")
 #print("logging out...")
 #after
def logging_in():
 print("logging in")
def fetching_data():
 print("fetching data")
def dispalying_dashboard():
 print("dispalyong dashboard")
def logging_out():
    print("logging out")
def user_activity():
    logging_in()
    logging_out()
    dispalying_dashboard()
    fetching_data()
user_activity()