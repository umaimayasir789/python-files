#before
print("welcome,stu1")
print("welcome,stu2")
print("welcome,stu3")
print("welcome,stu4")
#after
a =["stu1","stu2","stu3" ,"stu4"]
for i, a in enumerate(a, start=1):
    print(f"Item {i}: {a}")

    #another method
for i in range(1,5):
    print(f"welcme student,{i}")