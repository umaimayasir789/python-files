import tkinter as tk
def handle_click(event):
    print(f"Mouse clicked at X ={event.x},Y = {event.y}")
def handle_key(event):
     print(f"Key pressed:{event.char}")
window =tk.Tk()
button = tk.Button(window,text="click me")
button.pack()
entry =tk.Entry(window)
entry.pack()
button.bind("<Button-1>",handle_click)
button.bind("<Key>",handle_key)
window.mainloop()