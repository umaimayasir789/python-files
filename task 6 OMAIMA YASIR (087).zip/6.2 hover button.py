import tkinter as tk
def change_color(event):
 event.widget.config(bg="lightblue")
def reset_color(event):
 event.widget.config(bg="SystemButtonFace")  # Default button color
window =tk.Tk()
button =tk.Button( window, text="Hover Over Me")
button.pack(padx=20, pady=20)
button.bind("<Enter>",change_color)
button.bind("<Leave>",reset_color)
window.mainloop()