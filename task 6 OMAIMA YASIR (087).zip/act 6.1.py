import tkinter as tk
window=tk.Tk()    
label=tk.Label(window,text=("waiting......"))
label.pack()
def update_text():
 print("clicked")
button =tk.Button(window,text=("CLICK ME"),command=update_text)
button.pack()
window.mainloop()