import tkinter as tk
window =tk.Tk()
def show_coords(event):
    print(f"Clicked at X ={event.x},Y ={event.y}")
label =tk.Label(window,text="click anywhere on me",bg="lightblue",width=30,height=5)
label.pack()
label.bind("<Button-1>",show_coords)
window.mainloop()