import tkinter as tk
window =tk.Tk()
def on_resize(event):
    print(f"New width:{event.width},New height:{event.height}")
window.geometry("300x200")
window.bind("<configure>,on_resize")
window.mainloop()
