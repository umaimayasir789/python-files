import unittest                      #import the unittest module ,create test class 
class TestExample(unittest.TestCase):
   def test_addition(self):                 #test method define
       self.assertEqual(1 + 1, 3)             # condition true and false
if __name__ == '__main__':
 unittest.main()