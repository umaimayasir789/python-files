import unittest  
unittest.main()                    #import the unittest module ,create test class 