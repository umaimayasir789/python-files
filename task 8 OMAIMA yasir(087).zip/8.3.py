import unittest                     #multiple test in one class
class TestExample(unittest.TestCase):
 def test_addition(self):
    self.assertEqual(1 + 1, 2)
 def test_multiplication(self):
  self.assertEqual(2 * 5, 10)
 def test_subtraction(self):
    self.assertedEqual(10 - 4, 6)
if __name__ == '__main__':
    unittest.main()