
import unittest

class Calculator:
    def add(self, a, b):
        return a + b

    def subtract(self, a, b):
        return a - b

    def multiply(self, a, b):
        return a * b

    def divide(self, a, b):
        if b == 0:
            raise ZeroDivisionError("Cannot divide by zero")
        return a / b
class TestCalculator(unittest.TestCase):
    def setUp(self):
        self.calc = Calculator()

    def tearDown(self):
        print("Test completed")

    def test_add(self):
        test_cases = [
            (1, 2, 3),
            (5, 7, 12),
            (-1, 1, 0),
            (0, 0, 0)
        ]
        for num1, num2, expected_result in test_cases:
            result = self.calc.add(num1, num2)
            self.assertEqual(result, expected_result)

    def test_subtract(self):
        test_cases = [
            (5, 2, 3),
            (10, 7, 3),
            (-1, 1, -2),
            (0, 0, 0)
        ]
        for num1, num2, expected_result in test_cases:
            result = self.calc.subtract(num1, num2)
            self.assertEqual(result, expected_result)

    def test_multiply(self):
        test_cases = [
            (2, 3, 6),
            (5, 7, 35),
            (-1, 1, -1),
            (0, 0, 0)
        ]
        for num1, num2, expected_result in test_cases:
            result = self.calc.multiply(num1, num2)
            self.assertEqual(result, expected_result)

    def test_divide(self):
        test_cases = [
            (6, 2, 3),
            (10, 2, 5),
            (-1, 1, -1),
            (0, 1, 0)
        ]
        for num1, num2, expected_result in test_cases:
            result = self.calc.divide(num1, num2)
            self.assertEqual(result, expected_result)

        with self.assertRaises(ZeroDivisionError):
            self.calc.divide(10, 0)

if __name__ == '__main__':
    unittest.main()