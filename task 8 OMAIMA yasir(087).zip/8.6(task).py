import unittest
unittest.main()